<?php
session_start();
if (!isset($_SESSION['login_user'])) {
    header("location: login.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selamat Datang</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="welcome-container">
        <h1>Selamat Datang, <?php echo $_SESSION['login_user']; ?></h1>
        <a href="logout.php">Logout</a>
    </div>
</body>

</html>
