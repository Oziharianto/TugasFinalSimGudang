<h3>Sistem Informasi Manajemen Stok Barang-Gudang Versi 2023</h3>
  <p>Ini merupakan contoh suatu sistem informasi manajemen untuk pengelolaan barang-barang di gudang dari suatu perusahaan.</p>
  <p>Source code lengkap aplikasi ini bisa anda download di <a href="https://github.com/harrywitriyono/simgudang2023" target="_blank">https://github.com/harrywitriyono/simgudang2023</a></p>
  <p>Silahkan dimodifikasi sesuai dengan harapan anda.  Jangan lupa do'anya untuk kebaikan kita semua.</p>